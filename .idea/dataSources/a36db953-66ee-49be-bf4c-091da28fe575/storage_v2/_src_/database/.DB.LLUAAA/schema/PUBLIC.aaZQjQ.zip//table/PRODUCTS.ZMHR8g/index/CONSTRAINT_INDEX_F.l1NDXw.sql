create index CONSTRAINT_INDEX_F
    on PRODUCTS (TYPE_ID);

