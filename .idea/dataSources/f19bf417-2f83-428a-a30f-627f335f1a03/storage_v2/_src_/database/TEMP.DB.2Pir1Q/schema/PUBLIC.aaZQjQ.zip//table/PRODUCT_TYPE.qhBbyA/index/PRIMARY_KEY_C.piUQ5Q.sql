create unique index PRIMARY_KEY_C
    on PRODUCT_TYPE (ID);

