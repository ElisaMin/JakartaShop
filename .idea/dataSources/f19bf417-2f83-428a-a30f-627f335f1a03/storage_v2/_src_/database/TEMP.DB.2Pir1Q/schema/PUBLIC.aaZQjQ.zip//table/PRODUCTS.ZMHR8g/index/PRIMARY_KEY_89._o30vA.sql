create unique index PRIMARY_KEY_89
    on PRODUCTS (ID);

