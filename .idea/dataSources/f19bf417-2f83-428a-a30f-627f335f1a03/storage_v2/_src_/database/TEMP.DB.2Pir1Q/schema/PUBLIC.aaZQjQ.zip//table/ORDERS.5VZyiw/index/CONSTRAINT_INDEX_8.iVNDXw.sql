create index CONSTRAINT_INDEX_8
    on ORDERS (USER_ID);

